function [Pairings,Paired_Matrix] = Partner_Randi(Pairings_Matrix)
%PARTNER_RANDI
MAX = length(Pairings_Matrix);
y = 0;
Used_nums = [];
a = 0;
if mod(MAX,2) ~= 0
    a = 1;
    Pairings = zeros((MAX-1)/2,4);
    VALUE = (MAX-1)/2;
else
    Pairings = zeros(MAX/2,4);
    VALUE = MAX/2;
end

while y < VALUE 
        x = 0;
        while x == 0 
            A = randi([1 MAX],1,1);
            B = randi([1 MAX],1,1);
            C = randi([1 MAX],1,1);
            I = find(A == Used_nums);
            I2 = find(B == Used_nums);           
            I3 = find(C == Used_nums);
            if Pairings_Matrix(A,B) ~= 0 && Pairings_Matrix(B,A) ~= 0 
                if length(I) == 0 && length(I2) == 0 && a == 0
                    y = y + 1;
                    Pairings(y,2:4) = [A B 0];
                    Used_nums = [Used_nums A B];
                    x = 1;
                end
                if length(I3) == 0 && a == 1 && length(I) == 0 && length(I2) == 0
                    y = y + 1;
                    Pairings(y,2:4) = [A B C];
                    Used_nums = [Used_nums A B C];
                    Pairings_Matrix(A,C) = 0;
                    Pairings_Matrix(C,A) = 0;
                    Pairings_Matrix(B,C) = 0;
                    Pairings_Matrix(C,B) = 0;
                    a = 0;
                    x = 1;
                end
            end
        end
        Pairings_Matrix(A,B) = 0;
        Pairings_Matrix(B,A) = 0;
end

b = [1:VALUE]';
Pairings(:,1) = b;

Paired_Matrix = Pairings_Matrix;

end

