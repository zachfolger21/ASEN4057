function [m,b] = Best_fit(x,y)
%BEST_FIT.m
% Purpose: To take in an array of x and y values and output the best fit
% m and b values. (Best fit of degree 1)

% Inputs:   x - Array of 1 x N values
%           y - Array of 1 x N values

% Outputs:  m - slope of best fit line
%           b - Intersection of best fit line

%% Input Error Check
if length(x) ~= length(y)
    fprintf('Arrays must be the same length\n\n');
    m = NaN;
    b = NaN;
    return
end

%% Calculations
A = sum(x);
B = sum(y);
N = length(x);
for i = 1:N
    c(i) = x(i)*y(i);
    d(i) = x(i)*x(i);
end
C = sum(c);
D = sum(d);

m = (A*B - N*C)/(A^2 - N*D);
b = (A*C - B*D)/(A^2 - N*D);
end

