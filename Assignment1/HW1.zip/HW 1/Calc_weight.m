function [W_total] = Calc_weight(r,W_payload,W_empty,MW)
%CALC_WEIGHT_BALLOON
% Purpose: Write a MATLAB function which calculates the total weight of a 
% balloon given the radius of the balloon, the weight of the payload, the 
% weight of the balloon when empty, and the molecular weight of the gas 
% in the balloon.

% Inputs:   r -- Radius of the balloon [m]
%           W_payload -- Weight of payload [kg]
%           W_empty -- Weight of empty balloon [kg]
%           MW -- Molecular Weight of gas

% Outputs:  W_total -- Total weight of Balloon [kg]


%% Givens:
rho_0 = 1.225; %kg/m^3

%% Calculations

W_gas = (4*pi*rho_0*r^3*MW)/(3*28.966);
W_total = W_gas + W_payload + W_empty;

end

