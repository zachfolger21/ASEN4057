%% HW1 -  Problem 2 Main Script
% Author: Zach Folger
% Date Modified: 1/23

clear all; close all; clc

%% Initial Conditions
r = 3.0; %m
W_payload = 5; %kg
W_empty = 0.6;%kg
MW = 4.02;

%% Calculations

[Max_alt] = Calc_alt_max(r,W_payload,W_empty,MW);
fprintf('Maximum Attainable Altitude = %d meters\n',Max_alt);

