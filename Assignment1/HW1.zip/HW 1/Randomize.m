function [Pairings_Matrix,Pairings] = Randomize(N,M)
%RANDOMIZE
% Purpose: Function which randomizes the assignment pairings 
% for future paired programming assignments. The function takes as input the 
% number of students N and the number of paired assignments M. It avoids 
% repetitions of pairings within your student groups. If N is odd, the function
% designates one group of three students for each assignment.

% Inputs:   N -- Number of students in class
%           M -- Number of assignments in class

% Outputs:  Pairings -- Group pairs for each assigment during the
%                       semester

%% Input Error Checks
if N <= 1
    fprintf('Class must be larger than 1 student!!')
    return
end
if M < 1
    fprintf('Class must have at least 1 assignment!!')
    return
end

Max_assignments = N - 1;
if M > Max_assignments
    fprintf('Too Many Assignments For Number of Students Given')
    return
end


%% Analysis
% Assign a number to each individual student
Student_Num = 1:1:N;
% Assign a number to each Assignment
Assignment_Num = 1:1:M;
Pairings_Matrix = zeros(N,N);
for i = 1:N
    for j = 1:N
        Pairings_Matrix(i,j) = i;
        if i == j
            Pairings_Matrix(i,j) = 0;
        end
    end
end


fid = fopen('Assignment_Groups.txt','w');
for i = 1:M
    fprintf(fid,'Assignment #%d Groups:\n\n',i);
    [Pairings,Pairings_Matrix] = Partner_Randi(Pairings_Matrix);
    fprintf(fid,'Group%d -- %d %d %d\n',Pairings');
end
printf(fid,'\n\n',Pairings');
fclose(fid)


% if mod(N,2) == 1
%    Pairings.Assignment1(1,2:4) = randi(N,1,3);
% else
%     hola
% end

end

