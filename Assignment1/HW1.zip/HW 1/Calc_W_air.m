function [W_air] = Calc_W_air(r,alt)

%CALC_W_AIR Summary of this function goes here
% Purpose: Function which calculates the weight of the air a balloon 
% displaces given the radius and altitude of the balloon.  

% Inputs:   r -- Radius of Balloon [m]
%           alt -- Altitude of Balloon [m]

% Outputs:  W_air -- Weight of air despersed by balloon [kg]

%% Initial Conditions
[T,P] = Altitude_Conditions(alt);

%% Calculations:
rho = P/(.2869*(T+273.1));
W_air = (4*pi*rho*r^3)/3;


end

