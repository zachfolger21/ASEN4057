function [Max_alt] = Calc_alt_max(r,W_payload,W_empty,MW)
%CALC_ALT_MAX 
%Purpose: Function which computes the maximum attainable altitude of a 
% balloon given its radius, payload weight, and empty weight as well as the 
% molecular weight of the gas in the balloon. 

%To find the maximum attainable altitude, the function should calculate the 
%weight of the displaced air for an initial altitude of h= 0 m and then for
% altitude increments of h= 10 m (Hint:use a while loop).  
% Once the total weight of theballoon exceeds the weight of the displaced air,
%the balloon has reached its maximum altitude. 

% Inputs:   r -- Radius of the balloon [m]
%           W_payload -- Weight of payload [kg]
%           W_empty -- Weight of empty balloon [kg]
%           MW -- Molecular Weight of gas

% Outputs:  Max_alt -- Maximum acheivable altitude of balloon [m]

%% Givens:
alt = 0; %meters

%% Calculations:
[W_total] = Calc_weight(r,W_payload,W_empty,MW);
[W_air] = Calc_W_air(r,alt);


while W_total < W_air
    alt = alt + 10;
    [W_total] = Calc_weight(r,W_payload,W_empty,MW);
    [W_air] = Calc_W_air(r,alt);
end

Max_alt = alt;

end

