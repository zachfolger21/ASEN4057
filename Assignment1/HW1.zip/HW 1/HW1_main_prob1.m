%% HW1 - Problem 1 Main Script
% Author: Zach Folger
% Date Modified: 1/23

clear all; close all; clc

%% Initial Conditions
% USER INPUTS: 
string = 'Initial Velocity [m/s] of Ball = ';
theta = input(string); %[m/s] of balls initial speed. 
string = 'Launch Angle [deg] of Ball = ';
V = input(string); %[degrees] from x to y axis

g = -9.81; %m/s^2 (gravitational constant)

%% Calculations

% Solve for the time at which the ball arrives at it's initial height
syms t2
t_f = solve(0.5*g*t2^2 + V*sind(theta)*t2 == 0,t2); 
% Creating array of time values
t = linspace(0,t_f(2));

% Trajectory Calculations
x = V*cosd(theta).*t;
y = 0.5*g.*t.^2 + V*sind(theta).*t;

%% Plotting Results
figure;
hold on;
plot(x,y)
xlabel('X Position [m]')
ylabel('Y Position [m]')
title('Ball Trajectory Across Time');
plot(x,linspace(0,0),'r') %Floor below

figure;
subplot(2,1,1)
plot(t,x)
xlabel('Time [s]')
ylabel('X Position [m]')
title('X Position Vs Time');

subplot(2,1,2)
plot(t,y)
xlabel('Time [s]')
ylabel('Y Position [m]')
title('Y Position Vs Time');

