%% HW1 -  Problem 2 Main Script
% Author: Zach Folger
% Date Modified: 1/23

clear all; close all; clc

%% Initial Conditions
x = [-3 12.1 20 0 8 3.7 -5.6 0.5 5.8 10];
y = [-11.06 58.95 109.73 3.15 44.83 21.29 -27.29 5.11 34.01 43.25];


%% Calculations
[m,b] = Best_fit(x,y)


%% Testing for F-117 NightHawk

alpha = [-5 -2 0 2 3 5 7 10 14];
Cl= [-0.008 -0.003 0.001 0.005 0.007 0.006 0.009 0.017 0.019];
[m2,b2] = Best_fit(alpha,Cl);

alpha_new = linspace(-6,15);
Cl_new = m2*alpha_new + b2;

figure;
hold on;
plot(alpha,Cl,'*')
plot(alpha_new,Cl_new)
title('Best Fit of AoA vs Cl for F-117 NightHawk')
xlabel('Angle of Attack [deg]')
ylabel('Coefficient of Lift')
legend('Raw Data','Best Fit Data','location','best')

