function [T,P] = Altitude_Conditions(alt)
%ALTITUDE_CONDITIONS
% Purpose: To provide the temperature and pressure of air at a given
% altitude

% Inputs:   alt -- Altitude of Balloon [m]

% Outputs:  T -- Temperature at given altitude [C]
%           P -- Pressure at given altitude [kPa]

%% Input Error Check
if alt < 0
    fprintf('INVALID INPUT: Alt must be greater than 0\n\n')
    T = NaN;
    P = NaN;
    return
end

%% Calculations
if alt <= 11000
    T = 15.04 - 0.00649*alt;
    P = 101.298*((T+273.1)/288.08)^5.256;
end
if alt > 11000 && alt <=25000
    T = -56.46;
    P = 22.65*exp(1.73-0.000157*alt);
end
if alt > 25000
    T = -131.21 + 0.00299*alt;
    P = 2.488*((T+273.1)/216.6)^(-11.388);
end



end

