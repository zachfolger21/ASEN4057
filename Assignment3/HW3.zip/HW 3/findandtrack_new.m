function [] = findandtrack_new(prn,msec_to_process,fs,intfreq,HANDLE1,HANDLE2)
%findandtrack
%basic functionality to do GPS Bistatic Reflection Processing

% close all; fclose all; clear;  clc;
disp('GPS Bistatic Processing')

%%input parameters to set (specific to data file)
% prn=18;  %GPS satellite number (03 05 06 09 12 14 18 21 22 30 31 )
% msec_to_process = 1000;  %msec of data to process
% fs=4.096e6;  %sampling frequency
% intfreq=0e6;  %intermediate frequency
corrspacing=-28.1:0.05:1.1;  %correlator measurement spacing
%the following are now hard coded along with the complex data format
%filename='GPSantennaUp.sim';  %direct file
%filename2='GPSantennaDown.sim';  %reflected file

%%first open the direct data file and get first block of data to work with
fid=fopen('GPSantennaUp.sim','rb');  %open binary file containing direct data
rawdat=(fread(fid,2000000,'schar'))';  %read in 2M samples
rawdat=rawdat(1:2:end)+ i .* rawdat(2:2:end);  %convert to complex IQ pairs
fclose(fid);  %close the file

%%first do satellite acqusition and get approx code phase/freq estimate
disp('Initiating GPS satellite acquisition...')
[fq_est,cp_est,c_meas,testmat]=acq4(prn,intfreq,9000,rawdat,fs,4,0);
disp(['  Acquisition Metric is: ',num2str(c_meas(1)),' (should be >2.0)']); 
%refine the acqusition estimate to get better code phase/frequency
[fq_est,cp_est,c_meas,testmat]=acq4(prn,fq_est,400,rawdat,fs,10,0);
disp(['  Refined Acq Metric is: ',num2str(c_meas(1)),' (should be >2.0)']); 

%%now do the main bistatic tracking/processing
disp('Initiating GPS satellite signal tracking...')
tstart=tic;  %start the timer
[e_i,e_q,p_i,p_q,l_i,l_q,carrierfq,codefq] = ...
    gpstrackcorr(prn, cp_est, fq_est, fs, corrspacing, msec_to_process);
toc(tstart);

%%finished!
% disp('Finished!  Run scripts: corrplot.m or plotresults.m for results visualization')
%% Plotresults.m

h = subplot(2,1,1,'Parent',HANDLE1);plot(h,p_i .^2 + p_q .^ 2, 'g.-')
hold on
grid on
subplot(2,1,1,'Parent',HANDLE1),plot(h,e_i .^2 + e_q .^ 2, 'bx-')
subplot(2,1,1,'Parent',HANDLE1),plot(h,l_i .^2 + l_q .^ 2, 'r+-')
hold off
xlabel(h,'milliseconds')
ylabel(h,'amplitude')
title(h,'Correlation Results')
legend(h,'prompt','early','late')
h2 = subplot(2,2,3,'Parent',HANDLE1); plot(h2,p_i)
grid on
xlabel(h2,'milliseconds')
ylabel(h2,'amplitude')
title(h2,'Prompt I Channel')
h3 = subplot(2,2,4,'Parent',HANDLE1);plot(h3,p_q)
grid
xlabel(h3,'milliseconds')
ylabel(h3,'amplitude')
title(h3,'Prompt Q Channel')

h4 = subplot(2,1,1,'Parent',HANDLE2);plot(h4,1.023e6 - codefq)
grid on
xlabel(h4,'milliseconds')
ylabel(h4,'Hz')
title(h4,'Tracked Code Frequency (Deviation from 1.023MHz)')
h5 = subplot(2,1,2,'Parent',HANDLE2); plot(h5,carrierfq)
grid on
xlabel(h5,'milliseconds')
ylabel(h5,'Hz')
title(h5,'Tracked Intermediate Frequency')



end

