%% Initializations
function varargout = HW3_Folger(varargin)
% HW3_FOLGER MATLAB code for HW3_Folger.fig
%      HW3_FOLGER, by itself, creates a new HW3_FOLGER or raises the existing
%      singleton*.
%
%      H = HW3_FOLGER returns the handle to a new HW3_FOLGER or the handle to
%      the existing singleton*.
%
%      HW3_FOLGER('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in HW3_FOLGER.M with the given input arguments.
%
%      HW3_FOLGER('Property','Value',...) creates a new HW3_FOLGER or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before HW3_Folger_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to HW3_Folger_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help HW3_Folger

% Last Modified by GUIDE v2.5 13-Feb-2017 11:49:04

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @HW3_Folger_OpeningFcn, ...
                   'gui_OutputFcn',  @HW3_Folger_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT
end

% --- Executes just before HW3_Folger is made visible.
function HW3_Folger_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to HW3_Folger (see VARARGIN)

% Choose default command line output for HW3_Folger
handles.output = hObject;

% Setting all variables to an initial value in case they are not selected/
% altered
setappdata(handles.PRN_Number,'PRN_Number',3);
setappdata(handles.samp_freq,'Samp_Freq',4096000);
setappdata(handles.inter_freq,'Inter_Freq',0);
setappdata(handles.tspan_msec,'Time_Span',100);
setappdata(handles.average_tspan,'Time_Span_Average',10);
set(handles.start_animation,'Enable','off');
set(handles.average_tspan,'Enable','off');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes HW3_Folger wait for user response (see UIRESUME)
% uiwait(handles.figure1);
end

% --- Outputs from this function are returned to the command line.
function varargout = HW3_Folger_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
end

%% --- Executes on selection change in PRN_Number.
function PRN_Number_Callback(hObject, eventdata, handles)
% hObject    handle to PRN_Number (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns PRN_Number contents as cell array
%        contents{get(hObject,'Value')} returns selected item from PRN_Number
contents = get(hObject,'String');
actual = get(hObject,'Value');

switch contents{actual}
    case 'PRN 03'
        handles.current_data = 3;
    case 'PRN 05'
        handles.current_data = 5;
    case 'PRN 06'
        handles.current_data = 6;
    case 'PRN 09'
        handles.current_data = 9;
    case 'PRN 12'
        handles.current_data = 12;
    case 'PRN 14'
        handles.current_data = 14;
    case 'PRN 18'
        handles.current_data = 18;
    case 'PRN 21'
        handles.current_data = 21;
    case 'PRN 22'
        handles.current_data = 22;
    case 'PRN 30'
        handles.current_data = 30;
    case 'PRN 31'
        handles.current_data = 31;
end
setappdata(handles.PRN_Number,'PRN_Number',handles.current_data);
guidata(hObject,handles)
end
        
        
% --- Executes during object creation, after setting all properties.
function PRN_Number_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PRN_Number (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

%% Samp Freq Selection
function samp_freq_Callback(hObject, eventdata, handles)
% hObject    handle to samp_freq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of samp_freq as text
samp_freq = str2double(get(hObject,'String'));
% First checks for bad imputs (empty or not a number)
if isnan(samp_freq) == 1 || isempty(samp_freq) == 1
    set(handles.start,'Enable','off') 
else
    setappdata(handles.samp_freq,'Samp_Freq',samp_freq);
    set(handles.start,'Enable','on') 
end

guidata(hObject,handles)

end

% --- Executes during object creation, after setting all properties.
function samp_freq_CreateFcn(hObject, eventdata, handles)
% hObject    handle to samp_freq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

%% Inter Freq Selection
function inter_freq_Callback(hObject, eventdata, handles)
% hObject    handle to inter_freq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

inter_freq = str2double(get(hObject,'String'));
% First checks for bad imputs (empty or not a number)
if isnan(inter_freq) == 1 || isempty(inter_freq) == 1
    set(handles.start,'Enable','off') 
else
    setappdata(handles.inter_freq,'Inter_Freq',inter_freq);
    set(handles.start,'Enable','on') 
end

guidata(hObject,handles)
end

% --- Executes during object creation, after setting all properties.
function inter_freq_CreateFcn(hObject, eventdata, handles)
% hObject    handle to inter_freq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

%% Tspan Selection
function tspan_msec_Callback(hObject, eventdata, handles)
% hObject    handle to tspan_msec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

tspan = str2double(get(hObject,'String'));  
% First checks for bad imputs (empty or not a number)
if isnan(tspan) == 1 || isempty(tspan) == 1
    set(handles.start,'Enable','off') 
else
    setappdata(handles.tspan_msec,'Time_Span',tspan);
    set(handles.start,'Enable','on') 
end

guidata(hObject,handles)
end

% --- Executes during object creation, after setting all properties.
function tspan_msec_CreateFcn(hObject, eventdata, handles)
% hObject    handle to tspan_msec (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

%% Start Processing
% --- Executes on button press in start.
function start_Callback(hObject, eventdata, handles)
% hObject    handle to start (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% The following function was written for the animation plots
% It takes as inputs the handles to the panels for plotting and the values
% of the user input data
findandtrack_new(getappdata(handles.PRN_Number,'PRN_Number'),...
    getappdata(handles.tspan_msec,'Time_Span'),...
    getappdata(handles.samp_freq,'Samp_Freq'),...
    getappdata(handles.inter_freq,'Inter_Freq'),...
    handles.Amplitude_Panel,handles.Frequency_Panel);
% This allows the user to now input data for the animation
set(handles.start_animation,'Enable','on') 
set(handles.average_tspan,'Enable','on') 

end


%% Set Tspan Average
function average_tspan_Callback(hObject, eventdata, handles)
% hObject    handle to average_tspan (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of average_tspan as text
%        str2double(get(hObject,'String')) returns contents of average_tspan as a double
average_tspan = str2double(get(hObject,'String'));
% First checks for bad imputs (empty or not a number)
if isnan(average_tspan) == 1 || isempty(average_tspan) == 1
    set(handles.start_animation,'Enable','off') 
% Then check if the averaged time is larger than the time ran
elseif average_tspan > getappdata(handles.tspan_msec,'Time_Span')
    set(handles.start_animation,'Enable','off') 
else
    setappdata(handles.average_tspan,'Time_Span_Average',average_tspan);
    set(handles.start_animation,'Enable','on') 
end
guidata(hObject,handles)
end

% --- Executes during object creation, after setting all properties.
function average_tspan_CreateFcn(hObject, eventdata, handles)
% hObject    handle to average_tspan (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

%% Start Animation
% --- Executes on button press in start_animation.
function start_animation_Callback(hObject, eventdata, handles)
% hObject    handle to start_animation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% The following function was written for the animation plots
% It takes as inputs the average time and handles to the panels for
% plotting
Corrplot_func(handles.animation_panel,handles.animation_results,...
    getappdata(handles.average_tspan,'Time_Span_Average'))
end
