function dydt = MSE_model(t,y,params) %#ok<INUSL>
% kinematics and dynamics in inertial frame (N,E,D) coordinates
%   including gravity, buoyancy, and drag forces
% Inputs:
% state y = [x_S, y_S, Vx_S, Vy_S, x_M, y_M, Vx_M, Vy_M]
% Outputs:
% state rate of change dydt
% Methodology: uses F_E (inertial) coordinates throughout
% Parameters:
G = params(1);  %[kg]
mM = params(2);  %[m/s^2]
mE = params(3); % [kg/m^3]
mS = params(4); % [kg/m^3]
rM = params(5); % [m^3]
rE = params(6);
x_E = params(7); % [m^2]
y_E = params(8); % [m/s]
x_S = y(1);
y_S = y(2);
Vx_S = y(3);
Vy_S = y(4);
x_M = y(5);
y_M = y(6);
Vx_M = y(7);
Vy_M = y(8);
d_EM = sqrt((x_M-x_E)^2+(y_M-y_E)^2);
d_MS = sqrt((x_M-x_S)^2+(y_M-y_S)^2);
d_SE = sqrt((x_S-x_E)^2+(y_S-y_E)^2);

fg_SE_x = G*mS*mE*(x_S-x_E)/(d_SE^3);
fg_SE_y = G*mS*mE*(y_S-y_E)/(d_SE^3);
fg_ME_x = G*mM*mE*(x_M-x_E)/(d_EM^3);
fg_ME_y = G*mM*mE*(y_M-y_E)/(d_EM^3);
fg_SM = G*mM*mS/d_MS^2;
r_MS=[x_S;y_S]-[x_M;y_M];
r_MSu=r_MS/norm(r_MS);
fx_S = -fg_SE_x - fg_SM*r_MSu(1);
fy_S = -fg_SE_y - fg_SM*r_MSu(2);
fx_M = -fg_ME_x + fg_SM*r_MSu(1);
fy_M = -fg_ME_y + fg_SM*r_MSu(2);
% compute instantateous state derivatives
dydt = [Vx_S;...
    Vy_S;...
    fx_S/mS;...
    fy_S/mS;... 
    Vx_M;...
    Vy_M;...
    fx_M/mM;...
    fy_M/mM;...
    ];

%if (d_MS-rM) <= 0
%        fprintf('I hit the Moon\n')
%elseif (d_SE-rE) <= 0
%        fprintf('I made it!\n')
%elseif (2*d_EM -d_SE) <=0         
%    fprintf('I am lost........\n')
%end
end
