function  t_F = OptFunc_minT(V,IC,params)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
options = odeset('Event',@EventFunc,'RelTol',1e-12);
tspan =[0,60*60*24*28];
IC2= IC;
IC2(3:4) = [IC2(3)+V(1), IC2(4)+V(2)];

[t,y,TE,YE,IE] = ode45(@(t,y) MSE_model(t,y,params),tspan,IC2,options);
t_F=2000000000;
deltaV = sqrt(V(1)^2+V(2)^2);
if IE == 2 & deltaV <= 100
    t_F = TE;
end
end

