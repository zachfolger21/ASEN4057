function [value,isterminal,direction] = EventFunc(t,y)

dis1 = sqrt((y(1)-y(5))^2+(y(2)-y(6))^2);
dis2 = sqrt((y(1)-0)^2+(y(2)-0)^2);
value(1) = dis1-1737100;
value(2) = dis2-6371000;
value(3) = 2*384403000-dis2;
%if val1<=0 || val2<=0 || val3<=0
%    values = 0;
%end
isterminal(1) = 1;
isterminal(2) = 1;
isterminal(3) = 1;
direction(1) = 0;
direction(2) = 0;
direction(3) = 0;
end

