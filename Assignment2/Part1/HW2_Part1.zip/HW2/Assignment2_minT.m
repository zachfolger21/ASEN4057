%% Assignment 2 - ASEN 4057
% Authors: Zachary Folger & Benjamin Hutchinson
% Date Modified - 1/29/17
cc
profile on
%% Constants
G =  6.674*10^-11; %N(m/kg)2 - Gravitational Constant
mM = 7.34767309*10^22; % kg - Mass of moon
mE = 5.97219*10^24; %kg - Mass of Earth
mS = 28833; %kg - Mass of spacecraft
rM = 1737100; % m - Radius of moon
rE = 6371000; % m - Radius of Earth


%% Initial Conditions
%Earth
xE_0 = 0;% m
yE_0 = 0;% m

%Moon
dEM_0 = 384403000; % m - Initial distance from earth to moon
thetaM = 42.5; %degrees - Angle of Moon trajectory
vM_0 = sqrt((G*mE^2)/((mM+mE)*dEM_0));
xM_0 = dEM_0*cosd(thetaM);
yM_0 = dEM_0*sind(thetaM);
vMx_0 = -vM_0*sind(thetaM);
vMy_0 = vM_0*cosd(thetaM);

%Spacecraft
dES_0 = 340000000; %m from s/c to earth
thetaS = 50; %degrees - Angle of spacecraft
vS_0 = 1000; %m/s - Initial velocity of s/c
xS_0 = dES_0*cosd(thetaS);
yS_0 = dES_0*sind(thetaS);
vSx_0 = vS_0*cosd(thetaS);
vSy_0 = vS_0*sind(thetaS);
options = odeset('Event',@EventFunc);
t_min = 60*60*24*28;
IC = [xS_0; yS_0; vSx_0; vSy_0; xM_0; yM_0; vMx_0; vMy_0];
params = [G;mM;mE;mS;rM;rE;xE_0;yE_0];
tspan =[0,60*60*24*28];
for ii = -100:10:100
    for jj = -100:10:100
        IC(3:4) = [vSx_0 + ii, vSy_0 + jj];
        [t,y,TE,YE,IE] = ode45(@(t,y) MSE_model(t,y,params),tspan,IC,options);
        if IE == 2 & TE < t_min
            t_min = TE;
            min1 = ii;
            min2 = jj;
        end
    end
end


IC = [xS_0; yS_0; vSx_0; vSy_0; xM_0; yM_0; vMx_0; vMy_0];
params = [G;mM;mE;mS;rM;rE;xE_0;yE_0];
V_0 = [min1,min2];
[V_F,t_final] = fminsearch(@(V)OptFunc_minT(V,IC,params),V_0);

%% Perturbed Velocity
delta_vSx = V_F(1); %m/s -- first run to see if moon and s/c collide
delta_vSy = V_F(2);
vSx_0 = vSx_0 + delta_vSx;
vSy_0 = vSy_0 + delta_vSy;
deltaV = sqrt(V_F(1)^2 + V_F(2)^2);
tspan =[0,60*60*24*28];
IC(3:4) = [vSx_0, vSy_0];


 % state y = [x_S, y_S, Vx_S, Vy_S, x_M, y_M, Vx_M, Vy_M]
options = odeset('Event',@EventFunc,'RelTol',1e-12);
 [t,y,TE,YE,IE] = ode45(@(t,y) MSE_model(t,y,params),tspan,IC,options);
fprintf('The shortest trip time is %8.5f m/s with a burn of %2.5f m/s in the x direction\nand %2.5f m/s in the y direction\n',...
    TE, V_F(1),V_F(2))
 plot(y(:,1),y(:,2),'r.')
hold on
plot(y(:,5),y(:,6),'b--')
theta_vec = linspace(0,2*pi,1000);
cir_Ey = rE.*sin(theta_vec);
cir_Ex = rE.*cos(theta_vec);
cir_My = rM.*sin(theta_vec)+y(end,6);
cir_Mx = rM.*cos(theta_vec)+y(end,5);
plot(cir_Ex,cir_Ey,'g')
plot(cir_Mx,cir_My,'k')
axis equal
profile viewer